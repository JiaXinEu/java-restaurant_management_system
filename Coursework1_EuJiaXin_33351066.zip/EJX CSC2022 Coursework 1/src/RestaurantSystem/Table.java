package RestaurantSystem;

//class for table data
public class Table {
    private String tableNo;

    public String getTableNo() {
        return tableNo;
    }

    public void setTableNo(String tableNo) {
        this.tableNo = tableNo;
    }
}
