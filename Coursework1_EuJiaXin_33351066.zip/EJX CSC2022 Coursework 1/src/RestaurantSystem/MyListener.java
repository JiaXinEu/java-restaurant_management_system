package RestaurantSystem;

public interface MyListener {
    void onClickListener(Food food);
}
